Corpus Reader
=============

In addition to data, the ``chatterbot-corpus`` also includes utility methods
for accessing that data.

Python corpus reader
++++++++++++++++++++

.. autoclass:: chatterbot_corpus.corpus.Corpus
   :members:

