from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
import os

bot = ChatBot('Chrisa')
bot.set_trainer(ListTrainer)

for files in os.listdir("/media/ivan/7290378B6A2E9593/My Code/chatbot/chatterbot-corpus-master/chatterbot_corpus/data/english/"):
	data = open("/media/ivan/7290378B6A2E9593/My Code/chatbot/chatterbot-corpus-master/chatterbot_corpus/data/english/" + files , 'r').readlines()
	bot.train(data)

while True:
	request = input('You:')
	if request.strip() != "bye":
		response = bot.get_response(request)
		print('Chrisa: ' , response)
	if request.strip() == 'bye':
		print("Chrisa : Bye")
		break


